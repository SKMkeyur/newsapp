class Blogdata {
  String id;
  String title;
  String image;
  String desc;
  String t2;
  String caption;
  String published;
  Blogdata(this.id, this.title, this.image, this.desc, this.t2, this.caption,
      this.published);
}
