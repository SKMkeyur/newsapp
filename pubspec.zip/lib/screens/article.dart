import 'package:flutter/material.dart';
import 'package:newsapp/backend/backend.dart';
import 'package:newsapp/screens/a_article.dart';

class Article extends StatefulWidget {
  static const sid = '/article';
  @override
  _ArticleState createState() => _ArticleState();

  // State<StatefulWidget> createState() {
  //   return _ArticleState();
  // }

}

/// This is the private State class that goes with MyStatefulWidget.
class _ArticleState extends State<Article> {
  Blogdata blog_data;
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    void blog_datafun() async {
      blog_data = ModalRoute.of(context).settings.arguments;
      print(blog_data);
    }

    blog_datafun();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    const Key = ValueKey<String>('bottom-sliver-list');
    return Scaffold(
        body: CustomScrollView(slivers: <Widget>[
      SliverAppBar(
        pinned: true,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.grey),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Column(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_forward, color: Colors.grey),
                  onPressed: () {
                    setState(() {
                      Navigator.pushNamed(context, A_article.sid);
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                IconButton(
                  icon: const Icon(Icons.bookmark_border_outlined,
                      color: Colors.grey),
                  onPressed: () {
                    setState(() {
                      Navigator.pushNamed(context, A_article.sid);
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      SliverList(
          delegate: SliverChildListDelegate(
        [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                  padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
                  child: Container(
                      height: height / 4,
                      width: width,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: Color(0xfff4f4f6))),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.network(blog_data.image,
                              width: width,
                              height: height / 5,
                              fit: BoxFit.cover)))),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 0, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    TextButton(
                      child: Text("     News     ",
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Color(0xffffffff))),
                      style: ButtonStyle(
                          padding: MaterialStateProperty.all<EdgeInsets>(
                              EdgeInsets.fromLTRB(15, 5, 15, 5)),
                          backgroundColor: MaterialStateProperty.all<Color>(
                            Color(0xff475bd8),
                          ),
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ))),
                      onPressed: () {
                        Navigator.pushNamed(context, A_article.sid);
                        setState(() {});
                      },
                    )
                  ],
                ),
              ),
              Padding(
                  padding: const EdgeInsets.fromLTRB(15, 0, 0, 0),
                  child: Text(blog_data.title,
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.normal,
                          color: Color(0xff000000)))),
              Row(
                children: [
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(15, 15, 0, 0),
                        child: Image.network(blog_data.t2,
                            height: 72, width: 72, fit: BoxFit.cover),
                      )
                    ],
                  ),
                  Padding(
                      padding: const EdgeInsets.fromLTRB(15, 15, 0, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                  (() {
                                    if (blog_data.caption.toString().length >
                                        10) {
                                      return blog_data.caption
                                          .toString()
                                          .substring(0, 10);
                                    } else {
                                      if (blog_data.caption.toString() !=
                                          null) {
                                        return blog_data.caption.toString();
                                      } else {
                                        return "N/A";
                                      }
                                    }
                                  }()),
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff000000)))
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                  blog_data.published
                                      .toString()
                                      .substring(0, 10),
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xff676d87),
                                  ))
                            ],
                          ),
                        ],
                      )),
                ],
              ),
              Padding(
                  padding: const EdgeInsets.fromLTRB(15, 15, 0, 15),
                  child: Text("Read Here",
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold,
                          color: Color(0xff000000)))),
              Padding(
                padding: const EdgeInsets.fromLTRB(15, 0, 0, 0),
                child: Text(blog_data.desc.toString(),
                    style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.normal,
                        color: Colors.grey)),
              ),
            ],
          )
        ],
      ))
    ]));
  }
}
