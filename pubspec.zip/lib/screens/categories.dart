import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Categories extends StatefulWidget {
  static const sid = 'Categories';
  State<StatefulWidget> createState() {
    return _CategoriesState();
  }
}

class _CategoriesState extends State<Categories> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(title: Text('Carousel with indicator controller demo')),
        body: CustomScrollView(
      slivers: <Widget>[
        SliverList(
          delegate: SliverChildListDelegate([
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(15, 50, 0, 0),
                child: Text("Categories",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        fontSize: 25.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
              ),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 5, 0, 50),
              child: Text("Thousands of articles in each category",
                  style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey)),
            ),
            Padding(
                padding: const EdgeInsets.fromLTRB(15, 0, 0, 0),
                child: SingleChildScrollView(
                  child: Row(children: [
                    Expanded(
                      flex: 5,
                      child: Column(
                        children: [
                          GestureDetector(
                              onTap: () {
                                setState(() {
                                  // Navigator.pushNamed(context, Welcomescreen.sid);
                                });
                              },
                              child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 0, 15, 15),
                                  child: Container(
                                      height: 75,
                                      width: 170,
                                      decoration: BoxDecoration(
                                        color: Color(0xfff3f4f6),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 0, 0, 0),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Image.asset(
                                              'graphic_res/vball.png'),
                                        ),
                                      )))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 5,
                      child: Column(
                        children: [
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 15, 15),
                              child: Container(
                                  height: 75,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    color: Color(0xfff3f4f6),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Align(
                                        alignment: Alignment.center,
                                        child: IconButton(
                                          icon: const Icon(
                                              FontAwesomeIcons.footballBall,
                                              color: Color(0xff676d87)),
                                          onPressed: () {
                                            setState(() {
                                              // Navigator.pushNamed(context, Welcomescreen.sid);
                                            });
                                          },
                                        )),
                                  ))),
                        ],
                      ),
                    ),
                  ]),
                )),
          ]),
        )
      ],
    ));
  }
}
